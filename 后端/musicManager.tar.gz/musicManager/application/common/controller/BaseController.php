<?php

namespace app\common\controller;

use think\Controller;
use think\facade\Session;

class BaseController extends Controller
{
    protected $title = "挑给你音乐后台管理系统";
    //初始化
    protected function initialize()
    {
        define('USER_ID', session('user')['id']);
    }
    //返回统一数据格式  有数据
    static protected function showResCode($msg = '未知数据', $data = [], $code = 200)
    {
        $res = [
            'msg' => $msg,
            'data' => $data
        ];
        return json($res, $code);
    }
    //返回统一数据格式  无数据
    static protected function showResCodeWithOut($msg = '未知', $code = 200)
    {
        return self::showResCode($msg, [], $code);
    }
    //返回列表格式
    static protected function showList($count = 0, $data = [])
    {
        $arr = array();
        $arr['code'] = 0;
        $arr['msg'] = "获取成功";
        $arr['count'] = $count;
        $arr['data'] = $data;
        return json($arr);
    }
    //检测管理登录
    protected function isAdmin()
    {
        if (empty(USER_ID)) {
            $this->redirect('/login');  //跳转到登录页面
        }
    }
    //防止重复登录,如已登录直接跳转到首页
    protected function Logined()
    {
        if (!empty(USER_ID)) {
            $this->redirect('../');
        }
    }
}
