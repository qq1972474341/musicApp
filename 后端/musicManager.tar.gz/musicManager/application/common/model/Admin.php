<?php

namespace app\common\model;

use think\Model;

class Admin extends Model
{
    //管理员登录
    public function Login()
    {
        $param=request()->param();
        $user=$this->where('username',$param['username'])->where('password',sha1($param['password']))->find();
        if(!$user) TApiException('账号或密码错误');
        return $user;
    }
}
