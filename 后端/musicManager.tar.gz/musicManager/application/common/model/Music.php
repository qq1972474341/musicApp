<?php

namespace app\common\model;

use OSS\OssClient;
use OSS\Core\OssException;
use think\Model;


class Music extends Model
{
    //开启自动时间戳
    protected $autoWriteTimestamp = true;
    //统计音乐播放次数
    public function countPlayNum()
    {
        $id = request()->param('id');
        $info = $this->get($id);
        $info->playNum++;
        $info->save();
        if (!$info) TApiException('记录异常');
    }
    //获取音乐
    public function getMusic()
    {
        $page = request()->param('page');
        $limit = request()->param('limit');
        $type = request()->param('type');
        $arr['count'] = $this->where('type', $type)->count();
        $arr['list'] = $this->where('type', $type)->order('create_time', 'desc')->withAttr('create_time', function ($value, $data) {
            return  date('Y-m-d H:m:s', $value);
        })->withAttr('update_time', function ($value, $data) {
            return  date('Y-m-d H:m:s', $value);
        })->page($page, $limit)->select();
        return $arr;
    }
    //随机获取一首音乐
    public function getRandomMusic()
    {
        $count = $this->count();
        $music = $this->get(mt_rand(1, $count));
        return $music;
    }
    //搜索音乐
    public function searchMusic()
    {
        $page = request()->param('page');
        $limit = request()->param('limit');
        $keyword = request()->param('keyword');
        $arr['list'] = $this->where('title', 'like', '%' . $keyword . '%')->order('create_time', 'desc')->select();
        $arr['count'] = $arr['list']->count();
        return $arr;
    }
    //下一首歌曲
    public function nextMusic()
    {
        $music = $this->where('id', '<', request()->param('id'))->order('id', 'desc')->find();
        return $music;
    }
    //上一首歌曲
    public function lastMusic()
    {
        $music = $this->where('id', '>', request()->param('id'))->order('id', 'asc')->find();
        return $music;
    }
    //添加音乐
    public function AddMusic()
    {
        $params = request()->param();
        $time = strval(time());
        //取图片扩展名上传
        $params['img'] = $this->uploadOSS($params['title'] . $time . '.' . pathinfo($params['img'])['extension'], cache('img'.USER_ID))['url'];
        $params['cover'] = $this->uploadOSS($params['title'] . $time . '.' . pathinfo($params['cover'])['extension'], cache('cover'.USER_ID))['url'];
        //上传音乐资源
        $params['src'] = $this->uploadOSS($params['title'] . $time . '.mp3', cache('src'.USER_ID))['url'];
        if ($params['lyric'] != '') {
            $params['lyric'] = $this->uploadOSS($params['title'] . $time . '.txt', cache('lyric'.USER_ID))['url'];
        }
        $music = $this->create([
            'title' => $params['title'],
            'author' => $params['author'],
            'des' => $params['des'],
            'cover' => $params['cover'],
            'img' => $params['img'],
            'src' => $params['src'],
            'lyric' => array_key_exists('lyric', $params) ? $params['lyric'] : '',
            'playNum' => 0,
            'upload_author' => array_key_exists('upload_author', $params) ? $params['upload_author'] : '',
            'type' => $params['type']
        ]);
        if (!$music) TApiException('添加音乐失败', 20001, 500);
    }
    //删除音乐资源
    public function DelMusic()
    {
        $arr = request()->param('list');
        //OSS删除
        $delArr = [];
        $music = $this->all($arr);
        foreach ($music as $v) {
            array_push($delArr, urldecode(basename($v->cover)));  //封面图
            array_push($delArr, urldecode(basename($v->img)));    //展示图
            array_push($delArr, urldecode(basename($v->src)));    //音乐资源
            if ($v->lyric != '')  array_push($delArr, urldecode(basename($v->lyric)));
        }
        $this->deleteOSS($delArr);
        //数据库删除
        $del = $this->destroy($arr);
        if (!$del) TApiException('删除音乐资源失败');
    }
    //编辑音乐资源
    public function EditMusic()
    {
        $params = request()->param();
        $time = strval(time());
        $delArr = [];
        $music = $this->get($params['id']);
        if ($music->cover != $params['cover']) {
            array_push($delArr, urldecode(basename($music->cover))); //封面图
            $params['cover'] = $this->uploadOSS($params['title'] . $time . '.' . pathinfo($params['cover'])['extension'], cache('cover'.USER_ID))['url'];
        }
        if ($music->img != $params['img']) {
            array_push($delArr, urldecode(basename($music->img))); //展示图
            $params['img'] = $this->uploadOSS($params['title'] . $time . '.' . pathinfo($params['img'])['extension'], cache('img'.USER_ID))['url'];
        }
        $music->title = $params['title'];
        $music->author = $params['author'];
        $music->des = $params['des'];
        $music->cover = $params['cover'];
        $music->img = $params['img'];
        $music->upload_author = $params['upload_author'];
        $music->save();
    }
    //音乐资源、歌词文件提交到阿里云OSS
    public function uploadOSS($object, $filePath)
    {
        // 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建RAM账号。
        $accessKeyId = config('api.aliyun_oss.accessKeyId');
        $accessKeySecret = config('api.aliyun_oss.accessKeySecret');
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        $endpoint = config('api.aliyun_oss.endpoint');
        // 设置存储空间名称。
        $bucket =  config('api.aliyun_oss.bucket');
        // 设置文件名称。
        //$object = "<yourObjectName>";
        // <yourLocalFile>由本地文件路径加文件名包括后缀组成，例如/users/local/myfile.txt。
        //$filePath = "<yourLocalFile>";
        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
            $ret = $ossClient->uploadFile($bucket, $object, $filePath);
            //dump($ret['info']['url']);
            return ['code' => 200, 'msg' => 'OSS上传成功', 'url' => $ret['info']['url']];
        } catch (OssException $e) {
            //printf(__FUNCTION__ . ": FAILED\n");
            //printf($e->getMessage() . "\n");
            TApiException('OSS上传失败');
        }
        //print(__FUNCTION__ . ": OK" . "\n");
    }
    //从阿里云OSS删除文件
    public function deleteOSS($objects = [])
    {
        $accessKeyId = config('api.aliyun_oss.accessKeyId');
        $accessKeySecret = config('api.aliyun_oss.accessKeySecret');
        // Endpoint以杭州为例，其它Region请按实际情况填写。
        $endpoint =  config('api.aliyun_oss.endpoint');
        $bucket = config('api.aliyun_oss.bucket');
        // $objects = array();
        // $objects[] = "<yourObjectName1>";
        // $objects[] = "<yourObjectName2>";
        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
            $ret = $ossClient->deleteObjects($bucket, $objects);
            //dump($ret);
            return ['code' => 200, 'msg' => 'OSS删除成功成功'];
        } catch (OssException $e) {
            printf(__FUNCTION__ . ": FAILED\n");
            printf($e->getMessage() . "\n");
            TApiException('OSS删除失败');
        }
        print(__FUNCTION__ . ": OK" . "\n");
    }
}
