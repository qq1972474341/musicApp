<?php

namespace app\common\model;

use think\Model;

class User extends Model
{
    //开启自动时间戳
    protected $autoWriteTimestamp = true;
    //用户登录
    public function Login()
    {
        //微信用户登录
        $param = request()->param();
        $user = $this->where('openid', $param['openid'])->find();
        //无此用户自动创建账号
        if (!$user) {
            $user = self::create([
                'openid' => $param['openid'],
                'avatarUrl' => $param['avatarUrl'],
                'token' => $this->createSaveToken(),
                'nickName' => $param['nickName'],
                'playNum' => 15, //默认赠送15点播放
            ]);
            return $user;
        }
        $user->avatarUrl = $param['avatarUrl'];
        $user->nickName = $param['nickName'];
        //更新token
        $user->token = $this->createSaveToken();
        $user->save();
        return $user;
    }

    //生成token
    public function createSaveToken($arr = [])
    {
        //生成token
        return sha1(md5(uniqid(md5(microtime(true)), true)));
    }
    //用户听歌扣点
    public function SubPlayNum()
    {
        $token=request()->header()['token'];
        $user=$this->where('token',$token)->find();
        if(!$user) TApiException('无效token',10001,200);
        if($user->playNum>0) $user->playNum--;
        $user->save();
        return $user;
    }
    //用户看广告加点
    public function AddPlayNum()
    {
        $token=request()->header()['token'];
        $user=$this->where('token',$token)->find();
        if(!$user) TApiException('无效token',10001,200);
        if($user->playNum>0) $user->playNum++;
        $user->save();
        return $user;
    }
}
