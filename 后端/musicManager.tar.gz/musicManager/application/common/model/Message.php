<?php

namespace app\common\model;

use think\Model;

class Message extends Model
{
    //开启自动时间戳
    protected $autoWriteTimestamp = true;
    //获取消息列表
    public function getMessage()
    {
        $page = request()->param('page');
        $limit = request()->param('limit');
        $arr['count'] = $this->count();
        if (request()->param('APP') != NULL) {
            $arr['list'] = $this->order('create_time', 'desc')->withAttr('create_time', function ($value, $data) {
                return $value;
            })->page($page, $limit)->select();
        } else {
            $arr['list'] = $this->order('create_time', 'desc')->page($page, $limit)->select();
        }


        return $arr;
    }
    //添加消息通知
    public function AddMessage()
    {
        $params = request()->param();
        $music = $this->allowField(true)->save($params);
        if (!$music) TApiException('添加消息失败', 20001, 500);
    }
    //删除消息
    public function DelMessage()
    {
        $arr = request()->param('list');
        //数据库删除
        $del = $this->destroy($arr);
        if (!$del) TApiException('删除消息失败');
    }
    //编辑消息
    public function EditMessage()
    {
        $params = request()->param();
        $message = $this->get($params['id']);
        $message->title = $params['title'];
        $message->content = $params['content'];
        $message->save();
    }
}
