<?php

namespace app\common\model;

use think\Model;

class AppVersion extends Model
{
    //开启自动时间戳
    protected $autoWriteTimestamp = true;
    //修改应用版本信息
    public function modifyVersion()
    {
        $params = request()->param();
        if ($params['password'] != 'wei083684359') TApiException('你没有权限更改');
        $this->allowField(true)->save($params, ['id' => 1]);
    }
}
