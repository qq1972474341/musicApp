<?php

namespace app\api\controller\v1;

use app\common\controller\BaseController;
use app\common\model\User as ModelUser;
use app\common\validate\UserValidate;

class User extends BaseController
{
    //用户登录
    public function Login()
    {
        (new UserValidate())->goCheck('Login');
        $user=(new ModelUser())->Login();
        $user->code=200; //登录成功状态码
        return self::showResCode('登录成功',$user,200);
    }
    //听歌扣点
    public function SubPlayNum()
    {
        $user=(new ModelUser())->SubPlayNum();
        return self::showResCode('扣点成功',$user,200);
    }
     //看广告加点
     public function AddPlayNum()
     {
         $user=(new ModelUser())->AddPlayNum();
         return self::showResCode('加点成功',$user,200);
     }
}
