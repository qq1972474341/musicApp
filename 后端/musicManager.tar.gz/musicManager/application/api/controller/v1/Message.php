<?php

namespace app\api\controller\v1;

use app\common\controller\BaseController;
use app\common\model\Message as ModelMessage;

class Message extends BaseController
{
    //获取消息列表
    public function getMessage()
    {
        $arr = (new ModelMessage())->getMessage();
        return $this->showList($arr['count'], $arr['list']);
    }
    //增加消息
    public function AddMessage()
    {
        (new ModelMessage())->AddMessage();
        return self::showResCodeWithOut('添加消息成功');
    }
    //删除消息
    public function DelMessage()
    {
        (new ModelMessage())->DelMessage();
        return self::showResCodeWithOut('删除成功');
    }
    //编辑消息
    public function EditMessage()
    {
        (new ModelMessage())->EditMessage();
        return self::showResCodeWithOut('修改成功');
    }
}
