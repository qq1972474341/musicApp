<?php

namespace app\api\controller\v1;

use app\common\controller\BaseController;
use app\common\model\AppVersion;
use app\common\model\Music as ModelMusic;
use think\console\command\make\Model;

class Music extends BaseController
{
    //检查应用更新
    public function checkUpdate()
    {
        $data = request()->param();
        $info = AppVersion::get(1);
        $info->name = $data['name'];
        if (intval($info->hot_version) > intval($data['hot_version'])) {
            //热更新可更新返回数据
            $info->hot_update = true;
        }
        if (intval($info->app_version) > intval($data['app_version'])) {
            //APP更新可更新返回数据
            $info->app_update = true;
        }
        return $info;
    }
    //修改应用版本信息
    public function modifyVersion()
    {
        (new AppVersion())->modifyVersion();
        return $this->showResCodeWithOut('修改成功');
    }
    //统计音乐播放次数
    public function countPlayNum()
    {
        (new ModelMusic())->countPlayNum();
        return $this->showResCode('记录成功');
    }
    //获取音乐
    public function getMusic()
    {
        $arr = (new ModelMusic())->getMusic();
        return self::showList($arr['count'], $arr['list']);
    }
    //随机获取一首音乐
    public function getRandomMusic()
    {
        $music = (new ModelMusic())->getRandomMusic();
        return self::showResCode('获取成功', $music);
    }
    //下一首歌
    public function nextMusic()
    {
        $music = (new ModelMusic())->nextMusic();
        return self::showResCode('获取成功', $music);
    }
    //上一首歌
    public function lastMusic()
    {
        $music = (new ModelMusic())->lastMusic();
        return self::showResCode('获取成功', $music);
    }
    //搜索音乐
    public function searchMusic()
    {
        $arr = (new ModelMusic())->searchMusic();
        return self::showList($arr['count'], $arr['list']);
    }

    //添加音乐
    public function AddMusic()
    {
        (new ModelMusic())->AddMusic();
        return self::showResCodeWithOut('添加音乐成功');
    }
    //删除音乐
    public function DelMusic()
    {
        (new ModelMusic())->DelMusic();
        return self::showResCodeWithOut('删除成功');
    }
    //编辑音乐资源
    public function EditMusic()
    {
        (new ModelMusic())->EditMusic();
        return self::showResCodeWithOut('修改成功');
    }
    //上传文件资源到本地缓存
    public function upload()
    {
        $file = request()->file('file');
        // 移动到框架应用根目录/uploads/ 目录下
        $info = $file->move('uploads');
        // return;
        //上传的文件类型
        $type = request()->param('type');
        //缓存本地路径
        if ($info) {
            switch ($type) {
                case 'cover':
                    cache('cover'.USER_ID, dirname(__DIR__, 4) . '/public/uploads/' . $info->getSaveName(), 0);
                    break;
                case 'img':
                    cache('img'.USER_ID, dirname(__DIR__, 4) . '/public/uploads/' . $info->getSaveName(), 0);
                    break;
                case 'src':
                    cache('src'.USER_ID, dirname(__DIR__, 4) . '/public/uploads/' . $info->getSaveName(), 0);
                    break;
                case 'lyric':
                    cache('lyric'.USER_ID, dirname(__DIR__, 4) . '/public/uploads/' . $info->getSaveName(), 0);
                    break;
            }
            // $this->uploadOSS($info->getFilename(), $info->getInfo()['tmp_name']);
        } else {
            // 上传失败获取错误信息
            TApiException($file->getError());
        }
        return json(['msg' => $type . '上传成功', 'url' => request()->domain() . '/uploads/' . $info->getSaveName()]);
    }
}
