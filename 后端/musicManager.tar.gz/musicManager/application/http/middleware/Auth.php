<?php

namespace app\http\middleware;

class Auth
{
    public function handle($request, \Closure $next)
    {
        //用户未登陆情况
        if (!array_key_exists('token',$request->header())) TApiException('非法操作,禁止访问');
        return $next($request);
    }
}
