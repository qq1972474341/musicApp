<?php

namespace app\http\middleware;

class Admin
{
    public function handle($request, \Closure $next)
    {
        if (session('user')['id']==null) TApiException('非admin禁止操作');
        return $next($request);
    }
}
