<?php

namespace app\admin\controller;

use app\common\controller\BaseController;
use app\common\model\Admin;
use app\common\validate\UserValidate;

class User extends BaseController
{
    //登录-页面
    public function login()
    {
        $this->Logined();
        return $this->fetch();
    }
    //登录   
    public function AdminLogin()
    {
        (new UserValidate())->goCheck('AdminLogin');
        $user = (new Admin())->Login();
        session('user', $user);
        return self::showResCodeWithOut('登录成功', 200);
    }
    //登出
    public function logout()
    {
        session('user', null);
        $this->redirect('/login');
    }
}
