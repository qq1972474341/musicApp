<?php

namespace app\admin\controller;

use app\common\controller\BaseController;
use app\common\model\AppVersion;
use app\common\model\Message;
use app\common\model\Music;

class Index extends BaseController
{
    //APP版本管理-页面
    public function AppManager()
    {
        $this->assign('info', AppVersion::get(1));
        return $this->fetch();
    }
    //首页-页面
    public function index()
    {
        $this->isAdmin();
        return $this->fetch();
    }
    //音乐列表-页面
    public function MusicList()
    {
        $this->isAdmin();
        $this->assign('type', request()->param('type'));
        return $this->fetch();
    }

    //添加音乐弹出层-页面
    public function AddMusicPop()
    {
        $this->isAdmin();
        $this->assign('type', request()->param('type'));
        return $this->fetch('music-add');
    }
    //编辑音乐弹出层-页面
    public function EditMusicPop()
    {
        $this->isAdmin();
        $info = (new Music())->get(request()->param('id'));
        $this->assign('info', $info);
        return $this->fetch('music-edit');
    }
    //消息列表-页面
    public function MessageList()
    {
        $this->isAdmin();
        return $this->fetch();
    }
    //添加消息弹出层-页面
    public function AddMessagePop()
    {
        $this->isAdmin();
        return $this->fetch('message-add');
    }
    //编辑消息弹出层-页面
    public function EditMessagePop()
    {
        $this->isAdmin();
        $info = (new Message())->get(request()->param('id'));
        $this->assign('info', $info);
        return $this->fetch('message-edit');
    }
}
