<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

use think\facade\Route;
//登录页面
Route::rule('login', 'admin/User/login');
Route::rule('logout', 'admin/User/logout');
//登录接口
Route::rule('adminlogin', 'admin/User/AdminLogin');
//管理后台首页
Route::rule('/', 'admin/Index/index');
//管理员接口
Route::group('', function () {
    Route::rule('modifyVersion', 'api/v1.Music/modifyVersion'); //修改应用版本信息
    Route::rule('upload', 'api/v1.Music/upload'); //上传文件接口
    
    Route::rule('AddMusic', 'api/v1.Music/AddMusic'); //添加音乐数据到数据库
    Route::rule('DelMusic', 'api/v1.Music/DelMusic');  //删除音乐
    Route::rule('EditMusic/:id', 'api/v1.Music/EditMusic'); //编辑音乐

    Route::rule('AddMessage', 'api/v1.Message/AddMessage'); //添加消息通知数据到数据库
    Route::rule('DelMessage', 'api/v1.Message/DelMessage'); //删除消息
    Route::rule('EditMessage/:id', 'api/v1.Message/EditMessage'); //编辑消息
})->middleware('Admin');
Route::rule('checkUpdate', 'api/v1.Music/checkUpdate'); //上传文件接口
///*****接口***********************
//无需token验证
Route::group('api/:version/', function () {
    Route::post('user/login', 'api/:version.User/Login');  //用户登录
});
//需要token验证
Route::group('api/:version', function () {
    Route::post('user/subplaynum', 'api/:version.User/SubPlayNum'); //用户扣点
    Route::post('user/addplaynum', 'api/:version.User/AddPlayNum'); //用户加点
})->middleware('Auth');
