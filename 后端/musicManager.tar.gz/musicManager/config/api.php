<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | 应用设置
// +------
return [
    'aliyun_oss' => [
        'accessKeyId' => 'LTAI4FtYoideeYDyJyxCfTxi', //您的Access Key ID
        'accessKeySecret' => 'MjGew8Al2mGvULC1Q8hqrnomrNdBxQ', //您的Access Key Secret
        'endpoint' => 'oss-cn-beijing.aliyuncs.com', //阿里云oss 外网地址endpoint
        'bucket' => 'tmusic-bucket', //Bucket名称
        'url' => '' // 访问的地址
    ]
];
